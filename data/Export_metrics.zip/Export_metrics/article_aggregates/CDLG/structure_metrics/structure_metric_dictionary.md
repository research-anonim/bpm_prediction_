# Structure Drift Metric Dictionary

This export measures the topology representation supplied to the prediction model through prebuilt `process_structure.json` artifacts. It does not parse BPMN XML, use BPMN IDs as a metric, or claim that the scenarios represent live business-process change. The evidence supports the narrower statement: **structurally diverse and controlled drift scenarios**.

## Source And Identity

- `structure_source_path`: exact artifact consumed by the export.
- `structure_source_sha256`: SHA-256 of that artifact's bytes. A CDLG folder suffix is a process fingerprint only; it is not a SHA-256 digest.
- `process_fingerprint`: optional eight-hex folder suffix for CDLG process identification.
- `stratum`: `simple`, `middle`, or `complex`; local `cdlg-medium*` directories are reported as `middle`.

## Version Metrics

- `topology_layout`: `explicit_graph` for `dto.nodes` plus `dto.edges`, or `projected_allowed_edges` for `dto.node_metadata` plus allowed task-to-task edges.
- `raw_sequence_flow_count`: count of raw `dto.edges` entries whose `edge_type` is `sequence`; blank when that raw representation is unavailable.
- `projected_allowed_edge_count`: count of directed task-to-task topology edges consumed by prediction. For projected artifacts, these are the supplied allowed edges.
- `projected_node_metadata_count`: metadata-node count for projected artifacts; blank for explicit graphs.
- `canonical_task_relation_count`: count of task-to-task relations after traversing gateway/event nodes in explicit graphs, or the supplied projected allowed-edge count in projected artifacts.
- `*_gateway_count`: raw gateway counts by BPMN tag.
- `canonical_task_relation_cycle_present`: cycle detection on the canonical task relation graph.
- `branching_task_*` and `merge_task_*`: task nodes with canonical out-degree or in-degree greater than one.

## Transition Metrics

Each row compares adjacent versions only: v1->v2, v2->v3, v3->v4, v4->v5.

- `activity_jaccard`: intersection over union of the candidate activity universe. Projected artifacts use candidate node identities from allowed-edge endpoints.
- `relation_jaccard`: intersection over union of directed allowed task-to-task topology.
- `activity_set_delta`: `1 - activity_jaccard`, bounded in `[0, 1]`.
- `relation_set_delta`: `1 - relation_jaccard`, bounded in `[0, 1]`.
- `net_task_count_delta` and `net_relation_count_delta`: signed count changes. They are descriptive only, not structural distances.
- `relation_edit_count`: added plus removed canonical relations.
- `normalized_relation_edit_rate`: relation edits divided by the larger source/target relation count, or zero when both are empty.
- `change_type`: observable categories, not inferred causal labels.

## Reproduction

```powershell
.\.venv-modern\Scripts\python.exe tools\extract_structure_drift_metrics.py --dataset loan
.\.venv-modern\Scripts\python.exe tools\extract_structure_drift_metrics.py --dataset cdlg
```
